public class Printer implements Printable {
    private String name;

    public Printer() {
        heavyJob("产生一个Printer实例");
    }

    public Printer(String name) {
        this.name = name;
        heavyJob("正在生成Printer实例(" + name + ")");
    }

    public String getPrinterName() {                // 名前の取得
        return name;
    }

    public void setPrinterName(String name) {       // 名前の設定
        this.name = name;
    }

    public void print(String string) {
        System.out.println("=== " + name + " ===");
        System.out.println(string);
    }

    public void print(String string, int i) {

    }

    private void heavyJob(String msg) {
        System.out.print(msg);
        for (int i = 0; i < 5; i++) {
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
            }
            System.out.print(".");
        }
        System.out.println("生成完毕。");
    }
}
