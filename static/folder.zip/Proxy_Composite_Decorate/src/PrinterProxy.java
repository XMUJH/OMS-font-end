public class PrinterProxy implements Printable {
    private String name;            // 名前
    private Printer printer1;           // 「本人」
    private Printer printer2;
    private Printer printer3;

    public PrinterProxy() {
        realize();
    }

    public PrinterProxy(String name) {      // コンストラクタ
        this.name = name;
        realize();
    }

    public String getPrinterName() {    // 名前の取得
        return name;
    }

    public synchronized void setPrinterName(String name) {  // 名前の設定
        this.name = name;
        if (printer1.getPrinterName() != null) {
            printer1.setPrinterName(name);  // 「本人」にも設定する
        }
        if (printer2.getPrinterName() != null) {
            printer2.setPrinterName(name);
        }
        if (printer3.getPrinterName() != null) {
            printer3.setPrinterName(name);
        }
    }

    public void print(String string) {  // 表示
        //分配任务给这三台打印机，使它们同时工作。
        printer1.print(string);
        printer2.print(string);
        printer3.print(string);
    }
    //随机选择一台打印机分配任务，使这台打印机工作。
    public void print(String string , int i){
        if (i < 1 || i > 3) {
            System.out.println("请输入正确的打印机序号");
            return;
        }
        switch(i){
            case 1:
                printer1.print(string);
                break;
            case 2:
                printer2.print(string);
                break;
            case 3:
                printer3.print(string);
                break;
            default:
                break;
        }
    }
    public void printBorder(String string,int i) {
        System.out.println("************");
        print(string,i);
        System.out.println("************");
    }

    private synchronized void realize() {   // 「本人」を生成
        if (printer1 == null) {
            printer1 = new Printer(name);
        }
        if (printer2 == null) {
            printer2 = new Printer(name);
        }
        if (printer3 == null) {
            printer3 = new Printer(name);
        }
    }
}
