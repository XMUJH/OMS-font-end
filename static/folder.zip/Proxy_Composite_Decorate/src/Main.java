public class Main {
    public static void main(String[] args) {
        PrinterProxy p = new PrinterProxy("Alice");
        System.out.println("打印机现在的名字是" + p.getPrinterName() + "。");
        p.setPrinterName("Bob");
        System.out.println("打印机现在的名字是" + p.getPrinterName() + "。");
        System.out.println("将打印任务分配到三台打印机上完成");
        p.print("Hello, world.");
        System.out.println("将打印任务指定给打印机完成");
        p.print("Hello, world.",2);
        System.out.println("打印边框");
        p.printBorder("Hello world.",2);
    }
}
