import game.Gamer;

public class Main {
    public static void main(String[] args) {
        Gamer gamer = new Gamer(100);               // 初始持有100元现金

        for (int i = 0; i < 100; i++) {
            System.out.println("==== " + i);        // 回合数表示
            System.out.println("现在状态:" + gamer);    // 现在状态

            gamer.bet();    // 开始游戏

            System.out.println("现在持有" + gamer.getMoney() + "元。");

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
            }
            System.out.println("");
        }
    }
}
