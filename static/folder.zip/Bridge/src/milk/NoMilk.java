package milk;

/**
 * Created by lihen on 2017/5/15.
 */
public class NoMilk extends AbstractMilk {
    @Override
    public String toString(){
        return "No Milk";
    }

    @Override
    public void pour() {

    }
}
