package milk;

/**
 * Created by lihen on 2017/5/15.
 */
public class LowFat extends AbstractMilk {
    @Override
    public String toString(){
        return "Low Fat";
    }

    @Override
    public void pour() {
        System.out.println("Pouring low-fat milk...");
    }
}
