package milk;

/**
 * Created by 李恒贵 on 2017/5/15.
 * 抽象牛奶类
 */
public abstract class AbstractMilk {
    public abstract void pour();
}
