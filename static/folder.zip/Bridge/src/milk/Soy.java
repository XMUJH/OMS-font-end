package milk;

/**
 * Created by lihen on 2017/5/15.
 */
public class Soy extends AbstractMilk{
    @Override
    public String toString(){
        return "Soy Milk";
    }

    @Override
    public void pour() {
        System.out.println("Pouring soy milk...");
    }
}
