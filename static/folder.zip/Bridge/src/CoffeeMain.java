import coffee.*;
import foam.*;
import milk.*;
import size.*;
import size.Short;


public class CoffeeMain {
    public static void main(String[] args) {
        American americanCoffee = new American(new Tall());
        americanCoffee.pourCoffee();

        Cappuccino cappuccinoCoffee = new Cappuccino(new Venti(), new NoFoam(), new LowFat());
        cappuccinoCoffee.pourCoffee();

        Espresso espressoCoffee = new Espresso(new Grande(),new Light(),new NoMilk());
        espressoCoffee.pourCoffee();

        Mocha mochaCoffee = new Mocha(new Short(),new Extra(),new Soy());
        mochaCoffee.pourCoffee();
    }
}
