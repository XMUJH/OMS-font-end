package foam;

/**
 * Created by 李恒贵 on 2017/5/15.
 * 抽象泡沫类
 */
public abstract class AbstractFoam {
    int pourTimes;

    /**
     * 使用倾倒次数来表示泡沫量多少
     * 不倒为NoFoam,倒一次为Light，倒两次为Extra
     */
    public void pour() {
        for (int i = 0; i < pourTimes; i++) {
            System.out.println("Pouring foam...");
        }
    }
}
