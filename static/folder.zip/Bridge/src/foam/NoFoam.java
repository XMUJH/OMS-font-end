package foam;

/**
 * Created by lihen on 2017/5/15.
 */
public class NoFoam extends AbstractFoam{
    public NoFoam(){
        this.pourTimes = 0;
    }
    @Override
    public String toString(){
        return "NoFoam";
    }
}
