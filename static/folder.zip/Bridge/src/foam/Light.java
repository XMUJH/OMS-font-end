package foam;

/**
 * Created by lihen on 2017/5/15.
 */
public class Light extends AbstractFoam {
    public Light() {
        this.pourTimes = 1;
    }

    @Override
    public String toString() {
        return "Light Foam";
    }

}
