package foam;

/**
 * Created by lihen on 2017/5/15.
 */
public class Extra extends AbstractFoam {
    public Extra() {
        this.pourTimes = 2;
    }

    @Override
    public String toString() {
        return "Extra Light";
    }
}
