package size;

/**
 * Created by lihen on 2017/5/15.
 * 抽象杯子大小
 */
public abstract class AbstractSize {

    int pourTimes;

    public void pour() {
        //使用倒的次数来表示大小，倒一次是小杯,倒两次是中杯..
        //以此类推
        for (int i = 0; i < pourTimes; i++) {
            System.out.println("Pouring...");
        }
    }
}
