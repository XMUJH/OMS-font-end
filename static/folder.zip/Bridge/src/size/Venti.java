package size;

/**
 * Created by lihen on 2017/5/15.
 */
public class Venti extends AbstractSize {
    public Venti() {
        this.pourTimes = 4;
    }

    @Override
    public String toString() {
        return "Venti";
    }
}
