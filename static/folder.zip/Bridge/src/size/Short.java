package size;

/**
 * Created by lihen on 2017/5/15.
 */
public class Short extends AbstractSize {
    public Short() {
        this.pourTimes = 1;
    }

    @Override
    public String toString() {
        return "Short";
    }
}
