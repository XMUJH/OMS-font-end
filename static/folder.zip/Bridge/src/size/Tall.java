package size;

/**
 * Created by lihen on 2017/5/15.
 */
public class Tall extends AbstractSize {
    public Tall() {
        this.pourTimes = 2;
    }

    @Override
    public String toString() {
        return "Tall";
    }
}
