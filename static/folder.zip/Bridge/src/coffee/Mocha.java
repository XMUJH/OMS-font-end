package coffee;

import foam.AbstractFoam;
import milk.AbstractMilk;
import size.AbstractSize;

/**
 * Created by lihen on 2017/5/15.
 * 抹茶
 */
public class Mocha extends AbstractCoffee {
    public Mocha(AbstractSize size, AbstractFoam foam, AbstractMilk milk) {
        this.name = "Mocha coffee";
        this.size = size;
        this.foam = foam;
        this.milk = milk;
    }
}
