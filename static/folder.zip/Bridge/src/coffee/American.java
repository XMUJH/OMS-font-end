package coffee;

import size.AbstractSize;

/**
 * Created by 李恒贵 on 2017/5/15.
 * 美式咖啡的定义
 */
public class American extends AbstractCoffee {
    public American(AbstractSize size) {
        this.name = "American coffee";
        this.size = size;
    }

    @Override
    public void pourCoffee() {
        size.pour();
        System.out.println("A cup of " + name + ", size : " + size);
    }
}
