package coffee;

import foam.AbstractFoam;
import milk.AbstractMilk;
import size.AbstractSize;

/**
 * Created by lihen on 2017/5/15.
 * 浓缩咖啡
 */
public class Espresso extends AbstractCoffee {
    public Espresso(AbstractSize size, AbstractFoam foam, AbstractMilk milk) {
        this.name = "Espresso coffee";
        this.size = size;
        this.milk = milk;
        this.foam = foam;
    }
}
