package coffee;

import foam.AbstractFoam;
import milk.AbstractMilk;
import size.AbstractSize;

/**
 * Created by 李恒贵 on 2017/5/15.
 * 抽象咖啡类
 */
public abstract class AbstractCoffee {
    AbstractSize size;
    AbstractFoam foam;
    AbstractMilk milk;
    String name;

    public AbstractSize getSize() {
        return size;
    }

    public void setSize(AbstractSize size) {
        this.size = size;
    }

    public AbstractFoam getFoam() {
        return foam;
    }

    public void setFoam(AbstractFoam foam) {
        this.foam = foam;
    }

    public AbstractMilk getMilk() {
        return milk;
    }

    public void setMilk(AbstractMilk milk) {
        this.milk = milk;
    }

    public void pourCoffee() {
        size.pour();
        foam.pour();
        milk.pour();
        System.out.println("A cup of " + name + ", size : " + size + ", foam : " + foam + ", milk : " + milk);
    }
}
