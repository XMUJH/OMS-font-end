package coffee;

import foam.AbstractFoam;
import milk.AbstractMilk;
import size.AbstractSize;

/**
 * Created by lihen on 2017/5/15.
 * 卡布奇诺咖啡
 */
public class Cappuccino extends AbstractCoffee {
    public Cappuccino(AbstractSize size, AbstractFoam foam, AbstractMilk milk) {
        this.name = "Cappuccino coffee";
        this.size = size;
        this.foam = foam;
        this.milk = milk;
    }
}
